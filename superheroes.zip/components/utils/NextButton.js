import styles from './NextButton.module.css';

export default function NextButton() {
    return (
      <>
        <button className={styles.nextButton}>NEXT</button>
      </>
    )
}