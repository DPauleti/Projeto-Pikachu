/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/battle/[heroType]/[name]/page",{

/***/ "(app-pages-browser)/./app/battle/[heroType]/[name]/page.module.css":
/*!******************************************************!*\
  !*** ./app/battle/[heroType]/[name]/page.module.css ***!
  \******************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval(__webpack_require__.ts("// extracted by mini-css-extract-plugin\nmodule.exports = {\"battleContent\":\"page_battleContent__wOKwT\",\"herosSpace\":\"page_herosSpace__bDn7M\",\"heroImage\":\"page_heroImage__20CeC\"};\n    if(true) {\n      // 1748477313076\n      var cssReload = __webpack_require__(/*! ./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js */ \"(app-pages-browser)/./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js\")(module.id, {\"publicPath\":\"/_next/\",\"esModule\":false,\"locals\":true});\n      module.hot.dispose(cssReload);\n      \n    }\n  \nmodule.exports.__checksum = \"b9a2895d40fa\"\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL2FwcC9iYXR0bGUvW2hlcm9UeXBlXS9bbmFtZV0vcGFnZS5tb2R1bGUuY3NzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0Esa0JBQWtCO0FBQ2xCLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHdNQUEwSixjQUFjLHNEQUFzRDtBQUM1UCxNQUFNLFVBQVU7QUFDaEI7QUFDQTtBQUNBO0FBQ0EseUJBQXlCIiwic291cmNlcyI6WyJDOlxcVXNlcnNcXGRhbmllXFxPbmVEcml2ZVxcRG9jdW1lbnRvc1xcR2l0SHViXFxQcm9qZXRvUGlrYWNodVxcc3VwZXJoZXJvZXNcXGFwcFxcYmF0dGxlXFxbaGVyb1R5cGVdXFxbbmFtZV1cXHBhZ2UubW9kdWxlLmNzcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5cbm1vZHVsZS5leHBvcnRzID0ge1wiYmF0dGxlQ29udGVudFwiOlwicGFnZV9iYXR0bGVDb250ZW50X193T0t3VFwiLFwiaGVyb3NTcGFjZVwiOlwicGFnZV9oZXJvc1NwYWNlX19iRG43TVwiLFwiaGVyb0ltYWdlXCI6XCJwYWdlX2hlcm9JbWFnZV9fMjBDZUNcIn07XG4gICAgaWYobW9kdWxlLmhvdCkge1xuICAgICAgLy8gMTc0ODQ3NzMxMzA3NlxuICAgICAgdmFyIGNzc1JlbG9hZCA9IHJlcXVpcmUoXCJDOi9Vc2Vycy9kYW5pZS9PbmVEcml2ZS9Eb2N1bWVudG9zL0dpdEh1Yi9Qcm9qZXRvUGlrYWNodS9zdXBlcmhlcm9lcy9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NvbXBpbGVkL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2htci9ob3RNb2R1bGVSZXBsYWNlbWVudC5qc1wiKShtb2R1bGUuaWQsIHtcInB1YmxpY1BhdGhcIjpcIi9fbmV4dC9cIixcImVzTW9kdWxlXCI6ZmFsc2UsXCJsb2NhbHNcIjp0cnVlfSk7XG4gICAgICBtb2R1bGUuaG90LmRpc3Bvc2UoY3NzUmVsb2FkKTtcbiAgICAgIFxuICAgIH1cbiAgXG5tb2R1bGUuZXhwb3J0cy5fX2NoZWNrc3VtID0gXCJiOWEyODk1ZDQwZmFcIlxuIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(app-pages-browser)/./app/battle/[heroType]/[name]/page.module.css\n"));

/***/ })

});